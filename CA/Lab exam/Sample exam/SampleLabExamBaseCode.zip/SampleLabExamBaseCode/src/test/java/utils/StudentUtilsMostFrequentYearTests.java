package utils;

import org.junit.jupiter.api.Test;

class StudentUtilsMostFrequentYearTests {

    @Test
    void mostFrequentYear_BruteForce() {
    }

    @Test
    void mostFrequentYear_TwoPointer() {
    }
}