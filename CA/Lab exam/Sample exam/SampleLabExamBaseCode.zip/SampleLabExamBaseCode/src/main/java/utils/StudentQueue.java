package utils;

import entities.Student;

public class StudentQueue {
    public void enqueue(Student student){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public Student dequeue(){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public Student peek(){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public boolean isEmpty(){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public int size(){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }
}
