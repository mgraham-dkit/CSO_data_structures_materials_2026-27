package utils;

public class StudentNumberSet {

    public boolean add(String studentNum){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public boolean contains(String studentNum){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public boolean remove(String studentNum){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }

    public int size(){
        throw new UnsupportedOperationException("Operation has not been implemented yet.");
    }
}
